package com.kh.comp.run;

import com.kh.comp.func.CompExample;

public class Run {

	public static void main(String[] args) {

		CompExample ce = new CompExample();
//		ce.practice1();
//		ce.practice2();
//		ce.practice3();
		ce.practice4();
	}

}
